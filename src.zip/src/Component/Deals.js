// import React from 'react';
// import imagePath from '../Images/imagePath';
// import {View, Text, TouchableOpacity, Image} from 'react-native';

// function Deals(props){
//     return(
//         <View>
//         <View>
//           <TouchableOpacity>
//             <Image style={styles.shoes} source={shoe}/>
//           </TouchableOpacity>
//         </View>

//         <Text style={{fontWeight: 'bold', marginLeft: 5, marginTop: 10}}>
//           {shoeCompany}
//         </Text>
//         <Text style={{color: 'gray', marginLeft: 5}}>
//           {shoeName}
//         </Text>

//         <View style={styles.rowDirection}>
//           <Text>Rs 1,999</Text>
//           <Text
//             style={{
//               textDecorationLine: 'line-through',
//               textDecorationStyle: 'solid',
//               fontSize: 12,
//               marginTop: 2,
//               marginRight: 3,
//             }}>
//             Rs 2,555
//           </Text>
//           <Text style={{color: 'red'}}>38% OFF</Text>
// <TouchableOpacity style={{marginLeft: -130}}>
//   <Text style={{fontSize: 20, marginTop: 30, borderWidth: 2, borderRadius: 5,backgroundColor: '#FF69B4', color: 'white', borderColor:'#FF69B4', fontWeight: 'bold', marginBottom: 10}}>{button}</Text>
// </TouchableOpacity>
//         </View>
//       </View>
//     )
// }

// const styles = StyleSheet.create({
//     rowDirection: {
//       flexDirection: 'row',
//       marginTop: 10,
//     },
//     icon: {
//       width: 25,
//       height: 25,
//       marginRight: 10,
//     },
//     footware: {
//       fontSize: 20,
//       fontWeight: 'bold',
//       marginLeft: 30,
//       marginRight: 100,
//     },
//     items: {
//       marginTop: -10,
//       marginLeft: 45,
//       color: 'gray',
//     },
//     footwareImg: {
//       width: 350,
//       height: 50,
//       marginTop: 20,
//       marginLeft: 5,
//     },
//     shoes: {
//       width: 170,
//       height: 200,
//       marginRight: 8,
//       marginLeft: 5,
//     },
//   });
  