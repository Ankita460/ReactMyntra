// import React, {Component} from 'react';
// import {View, Text, Button, TouchableOpacity, Image} from 'react-native';
// import imagePath from '../../Images/imagePath';


// export default class OrderDetail extends Component{
//     constructor(props){
//         super(props)
        
//     }
// render(){
//     return(
//         <View>
//             <Text style={styles.heading}>
//                 Detail
//             </Text>
//            <Image source={imagePath.shoe1}/>
//         </View>
//     )
// }
// }

// const styles=StyleSheet.create({
//     heading:{
//         color: 'gray',
//         marginVertical: 10
//     }
// })